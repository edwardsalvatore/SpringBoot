#customer


create table Customer(id int primary key ,n_ame text,order_id int,phone bigint,email text);
alter table Customer modify phone bigint;


 insert into Customer values(11111111,"Priyali",1111111,6363969898,"jawaad1304@gmail.com"); 
 insert into Customer values(11111112,"Preethi",1111112,6363969898,"jawaad1304@gmail.com"); 
 
 #frougin
ALTER TABLE Customer
ADD CONSTRAINT FK_orderid
FOREIGN KEY (order_id) REFERENCES OrderDetails(orderid);