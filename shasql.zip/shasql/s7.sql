#ShopOwner

create table ShopOwer(id int primary key,n_ame text, dob date,address text,shop_id int);

insert into ShopOwer values(11111,"Saleem",'2000-10-11',"Bangalore",111); 
insert into ShopOwer values(11112,"Altamash",'2000-11-10',"Chintamani",112);

#foringn
alter table shopower add CONSTRAINT fk_shop_d FOREIGN KEY (shop_id)  
  REFERENCES Shop(shopid)  
  ON DELETE CASCADE  
  ON UPDATE CASCADE;

  
