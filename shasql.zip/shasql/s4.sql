#Mall Table
create table Mall(id bigint(50) primary key not null,mallAdmin int not null,mallName text not null,
location text not null,shop_id int not null,catagaori text not null);
#values
insert into Mall values(1,11,"SuperMall","Bangalore",111,"a1");  
insert into Mall values(2,12,"LuluMall","Chennai",112,"a2");

select * from MAll;
 
 #foregin key
ALTER TABLE Mall
ADD CONSTRAINT fk_mallAdmin FOREIGN KEY (mallAdmin)  
REFERENCES MallAdmin(id)  
ON DELETE CASCADE  
ON UPDATE CASCADE;

ALTER TABLE Mall
ADD CONSTRAINT fk_shop_id FOREIGN KEY (shop_id)  
  REFERENCES Shop(shopid)  
  ON DELETE CASCADE  
  ON UPDATE CASCADE ;

  