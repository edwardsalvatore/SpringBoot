#OrderDeatails
drop table OrderDetails;
create table OrderDetails(orderid int primary key,dateofpurchase date,total float,customer_id int,shop_id int);


 insert into OrderDetails values(1111111,"2022-09-11",300.0,11111111,111); 
 insert into OrderDetails values(1111112,"2022-09-11",300.0,11111111,111); 


#froeingn
 alter table orderdetsils add CONSTRAINT fk_shop_i FOREIGN KEY (shop_id)  
  REFERENCES Shop(shopid)  
  ON DELETE CASCADE  
  ON UPDATE CASCADE;
  
ALTER TABLE OrderDetails
ADD CONSTRAINT FK_customer__id
FOREIGN KEY (customer_id) REFERENCES customer(id);  
 

