#MallAdmin Table
create table MallAdmin(id int primary key,n_ame text, pass_word text,mall bigint(50), phone text);
#vales
insert into MallAdmin values(11,"Jawaad","Jawaad@123",1,"6363969894"); 
insert into MallAdmin values(12,"ShaShanka","Shanshan@123",2,"7619640359"); 

#foregin key
ALTER TABLE MallAdmin
ADD CONSTRAINT FK_mall
FOREIGN KEY (mall) REFERENCES Mall(id);

ALTER TABLE MallAdmin drop constraint FK_mall;
