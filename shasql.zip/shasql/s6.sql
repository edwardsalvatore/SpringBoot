#Item Table

create table Item(id bigint primary key,n_ame text,manufacturing date,expiry date,price float, catagory text);

insert into Item values(111111,"Sugar",'2022-10-11',"2024-10-11",50.0,"glosary"); 
insert into Item values(111112,"Rice",'2022-10-12',"2024-10-12",100.0,"food"); 