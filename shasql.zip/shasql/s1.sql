
#database
#create database Sha_project

use Sha_project;
select * from shop;
create table Shop(shopid int primary key,shopCatagory text,shopEmployeeID int,shopName text,customers text,
shopStsatus text,shopOwner int,leaseStatus text);

insert into shop values(112,"ab1",1111,"ZARA","sha1","open",11111,"cleared");
insert into shop values(111,"ab2",1112,"HM","sha2","open",11112,"cleared");


#foringn key

ALTER TABLE Shop
ADD CONSTRAINT FK_shopEmployeeID
FOREIGN KEY (shopEmployeeID) REFERENCES Employee(id);

ALTER TABLE Shop
ADD CONSTRAINT FK_shopEmplyeeId
FOREIGN KEY (shopOwner) REFERENCES ShopOwer(id);


-- cutomer -> 8, orderDetails -> 7,item -> 6,shopowner -> 5,employee -> 4,shop -> 3,mallAdmin -> 2, mall ->1

#user
create table userr(id int primary key,n_ame text,type text,pass_word text);

#insert
insert into userr values(12,"Saleem","MallAdmin","saleem");
insert into userr values(11,"Jawaad","MallAdmin","jawaad");


select * from userr;
select * from mall;
select * from malladmin;
select * from shop;
select * from shopower;
select * from employee;
select * from item;
select * from customer;
select * from orderdetails;



