#employee table
create table Employee(id int primary key,n_ame text, dob date,salary float,address text,designation text,shop_id int
);

insert into Employee values(1111,"Tejesh",'2020-10-22',50000.0,"Bangalore","Keeper",111);  
insert into Employee values(1112,"Manohar",'2010-10-22',40000.0,"Bangalore","Keeper",112); 
  
#forgin
Alter table Employee add CONSTRAINT fk_shopid FOREIGN KEY (shop_id)  
REFERENCES Shop(shopid)  
ON DELETE CASCADE  
ON UPDATE CASCADE;

select * from Employee;
