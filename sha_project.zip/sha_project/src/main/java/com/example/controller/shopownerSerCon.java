package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex.shopownerNotfoundException;
import com.example.model.shopowner;
import com.example.service.shopownerService;

@RestController
public class shopownerSerCon
{

	@Autowired
	private shopownerService shopownerService;

	@RequestMapping(value = "/shopowners", method = RequestMethod.POST)
	public ResponseEntity<Object> createshopowner(@RequestBody shopowner shopowner)
	{
		shopowner = shopownerService.createshopower(shopowner);
		return new ResponseEntity<>("shopowner is created successfully with id = " +shopowner.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/shopowners/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateshopowner(@PathVariable("id") int id,
			@RequestBody shopowner shopowner)
	{
		boolean isshopownerExist = shopownerService.isshopowerExist(id);
		if (isshopownerExist)
		{
			shopowner.setId(id);
			shopownerService.updateshopower(shopowner);
			return new ResponseEntity<>("shopowner is updated successsfully", HttpStatus.OK);
		}
		else
		{
			throw new shopownerNotfoundException();
		}

	}

	@RequestMapping(value = "/shopowners/{id}", method = RequestMethod.GET)
	public ResponseEntity<Object> getshopowner(@PathVariable("id") int id)
	{
		boolean isshopownerExist = shopownerService.isshopowerExist(id);
		if (isshopownerExist)
		{
			shopowner shopowner = shopownerService.getshopower(id);
			return new ResponseEntity<>(shopowner, HttpStatus.OK);
		}
		else
		{
			throw new shopownerNotfoundException();
		}

	}

	@RequestMapping(value = "/shopowner", method = RequestMethod.GET)
	public ResponseEntity<Object> getshopowner()
	{
		List<shopowner> shopownerList = shopownerService.getshopowers();
		return new ResponseEntity<>(shopownerList, HttpStatus.OK);
	}

	@RequestMapping(value = "/shopowners/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteshopowner(@PathVariable("id") int id)
	{
		boolean isshopownerExist = shopownerService.isshopowerExist(id);
		if (isshopownerExist)
		{
			shopownerService.deleteshopower(id);
			return new ResponseEntity<>("shopowner is deleted successsfully", HttpStatus.OK);
		}
		else
		{
			throw new shopownerNotfoundException();
		}

	}
	

}
