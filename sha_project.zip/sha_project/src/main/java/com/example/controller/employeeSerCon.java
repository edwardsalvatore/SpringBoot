package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex.employeeNotfoundException;
import com.example.model.employee;
import com.example.service.employeeService;

@RestController
public class employeeSerCon
{

	@Autowired
	private employeeService employeeService;

	@RequestMapping(value = "/employees", method = RequestMethod.POST)
	public ResponseEntity<Object> createemployee(@RequestBody employee employee)
	{
		employee = employeeService.createemployee(employee);
		return new ResponseEntity<>("employee is created successfully with id = " +employee.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/employees/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateemployee(@PathVariable("id") int id,
			@RequestBody employee employee)
	{
		boolean isemployeeExist = employeeService.isemployeeExist(id);
		if (isemployeeExist)
		{
			employee.setId(id);
			employeeService.updateemployee(employee);
			return new ResponseEntity<>("employee is updated successsfully", HttpStatus.OK);
		}
		else
		{
			throw new employeeNotfoundException();
		}

	}

	@RequestMapping(value = "/employees/{id}", method = RequestMethod.GET)
	public ResponseEntity<Object> getemployee(@PathVariable("id") int id)
	{
		boolean isemployeeExist = employeeService.isemployeeExist(id);
		if (isemployeeExist)
		{
			employee employee = employeeService.getemployee(id);
			return new ResponseEntity<>(employee, HttpStatus.OK);
		}
		else
		{
			throw new employeeNotfoundException();
		}

	}

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public ResponseEntity<Object> getemployee()
	{
		List<employee> employeeList = employeeService.getemployees();
		return new ResponseEntity<>(employeeList, HttpStatus.OK);
	}

	@RequestMapping(value = "/employees/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteemployee(@PathVariable("id") int id)
	{
		boolean isemployeeExist = employeeService.isemployeeExist(id);
		if (isemployeeExist)
		{
			employeeService.deleteemployee(id);
			return new ResponseEntity<>("employee is deleted successsfully", HttpStatus.OK);
		}
		else
		{
			throw new employeeNotfoundException();
		}

	}
	

}
