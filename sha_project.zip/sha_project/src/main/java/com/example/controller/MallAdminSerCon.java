package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex.MallAdminNotfoundException;
import com.example.model.MallAdmin;
import com.example.service.MallAdminService;

@RestController
public class MallAdminSerCon
{

	@Autowired
	private MallAdminService MallAdminService;

	@RequestMapping(value = "/MallAdmins", method = RequestMethod.POST)
	public ResponseEntity<Object> createMallAdmin(@RequestBody MallAdmin MallAdmin)
	{
		MallAdmin = MallAdminService.createMallAdmin(MallAdmin);
		return new ResponseEntity<>("MallAdmin is created successfully with id = " +MallAdmin.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/MallAdmins/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateMallAdmin(@PathVariable("id") int id,
			@RequestBody MallAdmin MallAdmin)
	{
		boolean isMallAdminExist = MallAdminService.isMallAdminExist(id);
		if (isMallAdminExist)
		{
			MallAdmin.setId(id);
			MallAdminService.updateMallAdmin(MallAdmin);
			return new ResponseEntity<>("MallAdmin is updated successsfully", HttpStatus.OK);
		}
		else
		{
			throw new MallAdminNotfoundException();
		}

	}

	@RequestMapping(value = "/MallAdmins/{id}", method = RequestMethod.GET)
	public ResponseEntity<Object> getMallAdmin(@PathVariable("id") int id)
	{
		boolean isMallAdminExist = MallAdminService.isMallAdminExist(id);
		if (isMallAdminExist)
		{
			MallAdmin MallAdmin = MallAdminService.getMallAdmin(id);
			return new ResponseEntity<>(MallAdmin, HttpStatus.OK);
		}
		else
		{
			throw new MallAdminNotfoundException();
		}

	}

	@RequestMapping(value = "/MallAdmin", method = RequestMethod.GET)
	public ResponseEntity<Object> getMallAdmin()
	{
		List<MallAdmin> MallAdminList = MallAdminService.getMallAdmin();
		return new ResponseEntity<>(MallAdminList, HttpStatus.OK);
	}

	@RequestMapping(value = "/MallAdmins/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteMallAdmin(@PathVariable("id") int id)
	{
		boolean isMallAdminExist = MallAdminService.isMallAdminExist(id);
		if (isMallAdminExist)
		{
			MallAdminService.deleteMallAdmin(id);
			return new ResponseEntity<>("MallAdmin is deleted successsfully", HttpStatus.OK);
		}
		else
		{
			throw new MallAdminNotfoundException();
		}

	}
	

}
