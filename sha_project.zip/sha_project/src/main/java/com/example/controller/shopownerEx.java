package com.example.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.ex.shopownerNotfoundException;

@ControllerAdvice
public class shopownerEx
{
	@ExceptionHandler(value = shopownerNotfoundException.class)
	public ResponseEntity<Object> exception(shopownerNotfoundException exception)
	{
		return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
	}
}
