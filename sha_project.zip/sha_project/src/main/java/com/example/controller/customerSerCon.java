package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex.customerNotfoundException;
import com.example.model.customer;
import com.example.service.customerService;

@RestController
public class customerSerCon
{

	@Autowired
	private customerService customerService;

	@RequestMapping(value = "/customers", method = RequestMethod.POST)
	public ResponseEntity<Object> createcustomer(@RequestBody customer customer)
	{
		customer = customerService.createcustomer(customer);
		return new ResponseEntity<>("customer is created successfully with id = " +customer.getId(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/customers/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updatecustomer(@PathVariable("id") int id,
			@RequestBody customer customer)
	{
		boolean iscustomerExist = customerService.iscustomerExist(id);
		if (iscustomerExist)
		{
			customer.setId(id);
			customerService.updatecustomer(customer);
			return new ResponseEntity<>("customer is updated successsfully", HttpStatus.OK);
		}
		else
		{
			throw new customerNotfoundException();
		}

	}

	@RequestMapping(value = "/customers/{id}", method = RequestMethod.GET)
	public ResponseEntity<Object> getcustomer(@PathVariable("id") int id)
	{
		boolean iscustomerExist = customerService.iscustomerExist(id);
		if (iscustomerExist)
		{
			customer customer = customerService.getcustomer(id);
			return new ResponseEntity<>(customer, HttpStatus.OK);
		}
		else
		{
			throw new customerNotfoundException();
		}

	}

	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public ResponseEntity<Object> getcustomer()
	{
		List<customer> customerList = customerService.getcustomers();
		return new ResponseEntity<>(customerList, HttpStatus.OK);
	}

	@RequestMapping(value = "/customers/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deletecustomer(@PathVariable("id") int id)
	{
		boolean iscustomerExist = customerService.iscustomerExist(id);
		if (iscustomerExist)
		{
			customerService.deletecustomer(id);
			return new ResponseEntity<>("customer is deleted successsfully", HttpStatus.OK);
		}
		else
		{
			throw new customerNotfoundException();
		}

	}
	

}
