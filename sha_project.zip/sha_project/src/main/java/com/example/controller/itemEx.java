package com.example.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.ex.itemNotfoundException;

@ControllerAdvice
public class itemEx
{
	@ExceptionHandler(value = itemNotfoundException.class)
	public ResponseEntity<Object> exception(itemNotfoundException exception)
	{
		return new ResponseEntity<>("item not found", HttpStatus.NOT_FOUND);
	}
}
