package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex.orderdetailsNotfoundException;
import com.example.model.orderdetails;
import com.example.service.orderdetailsService;

@RestController
public class orderdetailsSerCon
{

	@Autowired
	private orderdetailsService orderdetailsService;

	@RequestMapping(value = "/orderdetailss", method = RequestMethod.POST)
	public ResponseEntity<Object> createorderdetails(@RequestBody orderdetails orderdetails)
	{
		orderdetails = orderdetailsService.createorderdetails(orderdetails);
		return new ResponseEntity<>("orderdetails is created successfully with id = " +orderdetails.getOrderid(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/orderdetailss/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateorderdetails(@PathVariable("id") int id,
			@RequestBody orderdetails orderdetails)
	{
		boolean isorderdetailsExist = orderdetailsService.isorderdetailsExist(id);
		if (isorderdetailsExist)
		{
			orderdetails.setOrderid(id);
			orderdetailsService.updateorderdetails(orderdetails);
			return new ResponseEntity<>("orderdetails is updated successsfully", HttpStatus.OK);
		}
		else
		{
			throw new orderdetailsNotfoundException();
		}

	}

	@RequestMapping(value = "/orderdetailss/{id}", method = RequestMethod.GET)
	public ResponseEntity<Object> getorderdetails(@PathVariable("id") int id)
	{
		boolean isorderdetailsExist = orderdetailsService.isorderdetailsExist(id);
		if (isorderdetailsExist)
		{
			orderdetails orderdetails = orderdetailsService.getorderdetails(id);
			return new ResponseEntity<>(orderdetails, HttpStatus.OK);
		}
		else
		{
			throw new orderdetailsNotfoundException();
		}

	}

	@RequestMapping(value = "/orderdetails", method = RequestMethod.GET)
	public ResponseEntity<Object> getorderdetails()
	{
		List<orderdetails> orderdetailsList = orderdetailsService.getorderdetailss();
		return new ResponseEntity<>(orderdetailsList, HttpStatus.OK);
	}

	@RequestMapping(value = "/orderdetailss/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteorderdetails(@PathVariable("id") int id)
	{
		boolean isorderdetailsExist = orderdetailsService.isorderdetailsExist(id);
		if (isorderdetailsExist)
		{
			orderdetailsService.deleteorderdetails(id);
			return new ResponseEntity<>("orderdetails is deleted successsfully", HttpStatus.OK);
		}
		else
		{
			throw new orderdetailsNotfoundException();
		}

	}
	

}
