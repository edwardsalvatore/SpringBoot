package com.example.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.ex.UserrNotfoundException;

@ControllerAdvice
public class userEx
{
	@ExceptionHandler(value = UserrNotfoundException.class)
	public ResponseEntity<Object> exception(UserrNotfoundException exception)
	{
		return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
	}
}
