package com.example.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.ex.orderdetailsNotfoundException;

@ControllerAdvice
public class orderdetailsEx
{
	@ExceptionHandler(value = orderdetailsNotfoundException.class)
	public ResponseEntity<Object> exception(orderdetailsNotfoundException exception)
	{
		return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
	}
}
