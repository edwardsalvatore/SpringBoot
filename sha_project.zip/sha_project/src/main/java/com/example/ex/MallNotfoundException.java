package com.example.ex;


public class MallNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
