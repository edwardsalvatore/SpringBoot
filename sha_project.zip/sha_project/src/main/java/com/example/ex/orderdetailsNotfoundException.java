package com.example.ex;


public class orderdetailsNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
