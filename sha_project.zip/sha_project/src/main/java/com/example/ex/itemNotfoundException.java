package com.example.ex;


public class itemNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
