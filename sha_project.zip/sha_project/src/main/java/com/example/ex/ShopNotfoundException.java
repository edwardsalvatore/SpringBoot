package com.example.ex;


public class ShopNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
