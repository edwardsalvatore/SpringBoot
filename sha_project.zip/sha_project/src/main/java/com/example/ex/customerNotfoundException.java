package com.example.ex;


public class customerNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
