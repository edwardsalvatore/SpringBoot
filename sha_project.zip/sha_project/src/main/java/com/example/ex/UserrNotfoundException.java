package com.example.ex;


public class UserrNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
