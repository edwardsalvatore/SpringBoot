package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.orderdetails;  

public interface orderdetailsrespo extends CrudRepository<orderdetails, Integer>
{

}