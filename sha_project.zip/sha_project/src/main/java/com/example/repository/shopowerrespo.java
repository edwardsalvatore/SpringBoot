package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.shopowner;  

public interface shopowerrespo extends CrudRepository<shopowner, Integer>
{

}