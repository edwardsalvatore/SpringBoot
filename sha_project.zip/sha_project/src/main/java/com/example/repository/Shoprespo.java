package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.Shop;  

public interface Shoprespo extends CrudRepository<Shop, Integer>
{

}