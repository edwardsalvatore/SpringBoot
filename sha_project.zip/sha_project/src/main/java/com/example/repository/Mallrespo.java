package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.Mall;  

public interface Mallrespo extends CrudRepository<Mall, Integer>
{

}

