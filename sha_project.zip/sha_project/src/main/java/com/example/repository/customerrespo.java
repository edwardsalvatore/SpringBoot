package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.model.customer;  

public interface customerrespo extends CrudRepository<customer, Integer>
{

}