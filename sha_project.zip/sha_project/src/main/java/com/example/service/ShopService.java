package com.example.service;


import java.util.List;

import com.example.model.Shop;

public interface ShopService
{
	
	public abstract Shop createShop(Shop Shop);

	public abstract void updateShop(Shop Shop);
	
	public abstract Shop getShop(int id);
	
	public abstract List<Shop> getShops();
	
	public abstract void deleteShop(int id);
	
	public abstract boolean isShopExist(int id);
}