package com.example.service;


import java.util.List;

import com.example.model.shopowner;

public interface shopownerService
{
	
	public abstract shopowner createshopower(shopowner shopower);

	public abstract void updateshopower(shopowner shopower);
	
	public abstract shopowner getshopower(int id);
	
	public abstract List<shopowner> getshopowers();
	
	public abstract void deleteshopower(int id);
	
	public abstract boolean isshopowerExist(int id);
}