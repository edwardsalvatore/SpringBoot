package com.example.service;


import java.util.List;


import com.example.model.Userr;

public interface UserrService
{
	
	public abstract Userr createUserr(Userr Userr);

	public abstract void updateUserr(Userr Userr);
	
	public abstract Userr getUserr(int id);
	
	public abstract List<Userr> getUserrs();
	
	public abstract void deleteUserr(int id);
	
	public abstract boolean isUserrExist(int id);
}