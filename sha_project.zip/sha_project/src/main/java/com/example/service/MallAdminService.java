package com.example.service;


import java.util.List;

import com.example.model.MallAdmin;

public interface MallAdminService
{
	
	public abstract MallAdmin createMallAdmin(MallAdmin MallAdmin);

	public abstract void updateMallAdmin(MallAdmin MallAdmin);
	
	public abstract MallAdmin getMallAdmin(int id);
	
	public abstract List<MallAdmin> getMallAdmin();
	
	public abstract void deleteMallAdmin(int id);
	
	public abstract boolean isMallAdminExist(int id);

	
}