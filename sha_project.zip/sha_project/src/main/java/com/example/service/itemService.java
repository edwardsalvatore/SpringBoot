package com.example.service;


import java.util.List;

import com.example.model.item;

public interface itemService
{
	
	public abstract item createitem(item item);

	public abstract void updateitem(item item);
	
	public abstract item getitem(int id);
	
	public abstract List<item> getitems();
	
	public abstract void deleteitem(int id);
	
	public abstract boolean isitemExist(int id);
}