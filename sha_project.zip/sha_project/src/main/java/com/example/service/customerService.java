package com.example.service;


import java.util.List;

import com.example.model.customer;

public interface customerService
{
	
	public abstract customer createcustomer(customer customer);

	public abstract void updatecustomer(customer customer);
	
	public abstract customer getcustomer(int id);
	
	public abstract List<customer> getcustomers();
	
	public abstract void deletecustomer(int id);
	
	public abstract boolean iscustomerExist(int id);
}