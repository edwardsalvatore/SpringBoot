package com.example.service;


import java.util.List;

import com.example.model.orderdetails;

public interface orderdetailsService
{
	
	public abstract orderdetails createorderdetails(orderdetails orderdetails);

	public abstract void updateorderdetails(orderdetails orderdetails);
	
	public abstract orderdetails getorderdetails(int id);
	
	public abstract List<orderdetails> getorderdetailss();
	
	public abstract void deleteorderdetails(int id);
	
	public abstract boolean isorderdetailsExist(int id);
}