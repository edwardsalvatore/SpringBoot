package com.example.service;


import java.util.List;

import com.example.model.employee;

public interface employeeService
{
	
	public abstract employee createemployee(employee employee);

	public abstract void updateemployee(employee employee);
	
	public abstract employee getemployee(int id);
	
	public abstract List<employee> getemployees();
	
	public abstract void deleteemployee(int id);
	
	public abstract boolean isemployeeExist(int id);
}