package com.example.service;


import java.util.List;

import com.example.model.Mall;

public interface MallService
{
	
	public abstract Mall createMall(Mall Mall);

	public abstract void updateMall(Mall Mall);
	
	public abstract Mall getMall(int id);
	
	public abstract List<Mall> getMalls();
	
	public abstract void deleteMall(int id);
	
	public abstract boolean isMallExist(int id);
}