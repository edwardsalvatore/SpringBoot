package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Shop;
import com.example.repository.Shoprespo;
import com.example.service.ShopService;

@Service
public class ShopImpl implements ShopService
{

	@Autowired
	private Shoprespo Shoprespo;

	@Override
	public Shop createShop(Shop Shop)
	{
		return Shoprespo.save(Shop);
	}

	@Override
	public void updateShop(Shop Shop)
	{
		Shoprespo.save(Shop);
	}
	
	@Override
	public Shop getShop(int id)
	{
		Optional<Shop> optional = Shoprespo.findById(id);
		Shop Shop = optional.get();
		return Shop;
	}

	@Override
	public List<Shop> getShops()
	{
		return (List<Shop>)Shoprespo.findAll();
	}

	@Override
	public void deleteShop(int id)
	{
		Shoprespo.deleteById(id);
	}

	@Override
	public boolean isShopExist(int id)
	{
		return Shoprespo.existsById(id);
	}
}
