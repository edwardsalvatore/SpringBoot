package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Mall;
import com.example.repository.Mallrespo;
import com.example.service.MallService;

@Service
public class MallImpl implements MallService
{

	@Autowired
	private Mallrespo Mallrespo;

	@Override
	public Mall createMall(Mall Mall)
	{
		return Mallrespo.save(Mall);
	}

	@Override
	public void updateMall(Mall Mall)
	{
		Mallrespo.save(Mall);
	}
	
	@Override
	public Mall getMall(int id)
	{
		Optional<Mall> optional = Mallrespo.findById(id);
		Mall Mall = optional.get();
		return Mall;
	}

	@Override
	public List<Mall> getMalls()
	{
		return (List<Mall>)Mallrespo.findAll();
	}

	@Override
	public void deleteMall(int id)
	{
		Mallrespo.deleteById(id);
	}

	@Override
	public boolean isMallExist(int id)
	{
		return Mallrespo.existsById(id);
	}
}
