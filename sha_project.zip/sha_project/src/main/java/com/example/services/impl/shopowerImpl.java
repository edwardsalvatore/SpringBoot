package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.shopowner;
import com.example.repository.shopowerrespo;
import com.example.service.shopownerService;

@Service
public class shopowerImpl implements shopownerService
{

	@Autowired
	private shopowerrespo shopowerrespo;

	@Override
	public shopowner createshopower(shopowner shopower)
	{
		return shopowerrespo.save(shopower);
	}

	@Override
	public void updateshopower(shopowner shopower)
	{
		shopowerrespo.save(shopower);
	}
	
	@Override
	public shopowner getshopower(int id)
	{
		Optional<shopowner> optional = shopowerrespo.findById(id);
		shopowner shopower = optional.get();
		return shopower;
	}

	@Override
	public List<shopowner> getshopowers()
	{
		return (List<shopowner>)shopowerrespo.findAll();
	}

	@Override
	public void deleteshopower(int id)
	{
		shopowerrespo.deleteById(id);
	}

	@Override
	public boolean isshopowerExist(int id)
	{
		return shopowerrespo.existsById(id);
	}
}
