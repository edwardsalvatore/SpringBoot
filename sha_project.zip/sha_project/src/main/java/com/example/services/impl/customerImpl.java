package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.customer;
import com.example.repository.customerrespo;
import com.example.service.customerService;

@Service
public class customerImpl implements customerService
{

	@Autowired
	private customerrespo customerrespo;

	@Override
	public customer createcustomer(customer customer)
	{
		return customerrespo.save(customer);
	}

	@Override
	public void updatecustomer(customer customer)
	{
		customerrespo.save(customer);
	}
	
	@Override
	public customer getcustomer(int id)
	{
		Optional<customer> optional = customerrespo.findById(id);
		customer customer = optional.get();
		return customer;
	}

	@Override
	public List<customer> getcustomers()
	{
		return (List<customer>)customerrespo.findAll();
	}

	@Override
	public void deletecustomer(int id)
	{
		customerrespo.deleteById(id);
	}

	@Override
	public boolean iscustomerExist(int id)
	{
		return customerrespo.existsById(id);
	}
}
