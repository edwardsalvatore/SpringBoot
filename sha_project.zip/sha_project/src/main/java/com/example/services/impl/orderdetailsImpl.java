package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.orderdetails;
import com.example.repository.orderdetailsrespo;
import com.example.service.orderdetailsService;

@Service
public class orderdetailsImpl implements orderdetailsService
{

	@Autowired
	private orderdetailsrespo orderdetailsrespo;

	@Override
	public orderdetails createorderdetails(orderdetails orderdetails)
	{
		return orderdetailsrespo.save(orderdetails);
	}

	@Override
	public void updateorderdetails(orderdetails orderdetails)
	{
		orderdetailsrespo.save(orderdetails);
	}
	
	@Override
	public orderdetails getorderdetails(int id)
	{
		Optional<orderdetails> optional = orderdetailsrespo.findById(id);
		orderdetails orderdetails = optional.get();
		return orderdetails;
	}

	@Override
	public List<orderdetails> getorderdetailss()
	{
		return (List<orderdetails>)orderdetailsrespo.findAll();
	}

	@Override
	public void deleteorderdetails(int id)
	{
		orderdetailsrespo.deleteById(id);
	}

	@Override
	public boolean isorderdetailsExist(int id)
	{
		return orderdetailsrespo.existsById(id);
	}
}
