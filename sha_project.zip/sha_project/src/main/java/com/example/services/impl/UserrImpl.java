package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.model.Userr;
import com.example.repository.Userrespo;
import com.example.service.UserrService;

@Service
public class UserrImpl implements UserrService
{

	@Autowired
	private Userrespo Userrespo;
	
	@Override
	public Userr createUserr(Userr Userr)
	{
		return Userrespo.save(Userr);
	}

	@Override
	public void updateUserr(Userr Userr)
	{
		Userrespo.save(Userr);
	}
	
	@Override
	public Userr getUserr(int id)
	{
		Optional<Userr> optional = Userrespo.findById(id);
		Userr Userr = optional.get();
		return Userr;
	}

	@Override
	public List<Userr> getUserrs()
	{
		return (List<Userr>)Userrespo.findAll();
	}

	@Override
	public void deleteUserr(int id)
	{
		Userrespo.deleteById(id);
	}

	@Override
	public boolean isUserrExist(int id)
	{
		return Userrespo.existsById(id);
	}
}
