package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.employee;
import com.example.repository.employeerespo;
import com.example.service.employeeService;

@Service
public class employeeImpl implements employeeService
{

	@Autowired
	private employeerespo employeerespo;

	@Override
	public employee createemployee(employee employee)
	{
		return employeerespo.save(employee);
	}

	@Override
	public void updateemployee(employee employee)
	{
		employeerespo.save(employee);
	}
	
	@Override
	public employee getemployee(int id)
	{
		Optional<employee> optional = employeerespo.findById(id);
		employee employee = optional.get();
		return employee;
	}

	@Override
	public List<employee> getemployees()
	{
		return (List<employee>)employeerespo.findAll();
	}

	@Override
	public void deleteemployee(int id)
	{
		employeerespo.deleteById(id);
	}

	@Override
	public boolean isemployeeExist(int id)
	{
		return employeerespo.existsById(id);
	}
}
