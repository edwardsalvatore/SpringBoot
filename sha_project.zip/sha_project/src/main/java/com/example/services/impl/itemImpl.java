package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.item;
import com.example.repository.itemrespo;
import com.example.service.itemService;

@Service
public class itemImpl implements itemService
{

	@Autowired
	private itemrespo itemrespo;

	@Override
	public item createitem(item item)
	{
		return itemrespo.save(item);
	}

	@Override
	public void updateitem(item item)
	{
		itemrespo.save(item);
	}
	
	@Override
	public item getitem(int id)
	{
		Optional<item> optional = itemrespo.findById(id);
		item item = optional.get();
		return item;
	}

	@Override
	public List<item> getitems()
	{
		return (List<item>)itemrespo.findAll();
	}

	@Override
	public void deleteitem(int id)
	{
		itemrespo.deleteById(id);
	}

	@Override
	public boolean isitemExist(int id)
	{
		return itemrespo.existsById(id);
	}
}
