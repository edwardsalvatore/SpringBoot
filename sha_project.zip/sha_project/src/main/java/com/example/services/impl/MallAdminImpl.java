package com.example.services.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.model.MallAdmin;
import com.example.repository.MallAdminrespo;
import com.example.service.MallAdminService;

@Service
public class MallAdminImpl implements MallAdminService
{

	@Autowired
	private MallAdminrespo MallAdminrespo;
	
	@Override
	public MallAdmin createMallAdmin(MallAdmin MallAdmin)
	{
		return MallAdminrespo.save(MallAdmin);
	}

	@Override
	public void updateMallAdmin(MallAdmin MallAdmin)
	{
		MallAdminrespo.save(MallAdmin);
	}
	
	@Override
	public MallAdmin getMallAdmin(int id)
	{
		Optional<MallAdmin> optional = MallAdminrespo.findById(id);
		MallAdmin MallAdmin = optional.get();
		return MallAdmin;
	}

	@Override
	public List<MallAdmin> getMallAdmin()
	{
		return (List<MallAdmin>)MallAdminrespo.findAll();
	}

	@Override
	public void deleteMallAdmin(int id)
	{
		MallAdminrespo.deleteById(id);
	}

	@Override
	public boolean isMallAdminExist(int id)
	{
		return MallAdminrespo.existsById(id);
	}
}
