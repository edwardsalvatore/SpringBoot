package com.example.model;


import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
public class employee{
		@Id
		private int id;
		private String n_ame; 
		private String dob;
		private float salary;
		private String address;
		private String designation;
		private String shop_id;
	
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getN_ame() {
			return n_ame;
		}
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public float getSalary() {
			return salary;
		}
		public void setSalary(float salary) {
			this.salary = salary;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getShop_id() {
			return shop_id;
		}
		public void setShop_id(String shop_id) {
			this.shop_id = shop_id;
		}
		@Override
		public String toString() {
			return "employee [id=" + id + ", n_ame=" + n_ame + ", dob=" + dob + ", salary=" + salary + ", address="
					+ address + ", designation=" + designation + ", shop_id=" + shop_id + "]";
		}
}