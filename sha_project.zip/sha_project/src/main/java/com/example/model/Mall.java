

	package com.example.model;


	import javax.persistence.Id;

	import org.springframework.boot.autoconfigure.domain.EntityScan;
	import javax.persistence.Entity;


	@Entity
	public class Mall{
			@Id
			private int id;
			private int malladmin;
			private String mallname;
			private String location;
			private int shop_id;
			private String catagaori;
			@Override
			public String toString() {
				return "Mall [id=" + id + ", mallAdmin=" + malladmin + ", mallName=" + mallname + ", location="
						+ location + ", shop_id=" + shop_id + ", catagaori=" + catagaori + "]";
			}
			public int getId() {
				return id;
			}
			public void setId(int id) {
				this.id = id;
			}
			public int getMallAdmin() {
				return malladmin;
			}
			public void setMallAdmin(int mallAdmin) {
				this.malladmin = mallAdmin;
			}
			public String getMallName() {
				return mallname;
			}
			public void setMallName(String mallName) {
				this.mallname = mallName;
			}
			public String getLocation() {
				return location;
			}
			public void setLocation(String location) {
				this.location = location;
			}
			public int getShop_id() {
				return shop_id;
			}
			public void setShop_id(int shop_id) {
				this.shop_id = shop_id;
			}
			public String getCatagaori() {
				return catagaori;
			}
			public void setCatagaori(String catagaori) {
				this.catagaori = catagaori;
			}
}
