package com.example.model;


import javax.persistence.Id;




import javax.persistence.Entity;


@Entity

public class Userr{
		@Id
		
		private int id;
		private String n_ame;
		private String type;
		private String pass_word;
		@Override
		public String toString() {
			return "Userr [id=" + id + ", n_ame=" + n_ame + ", type=" + type + ", pass_word=" + pass_word + "]";
		}
		
		public int getId() {
			return id;
		}
		
		public void setId(int id) {
			this.id = id;
		}
		
		public String getN_ame() {
			return n_ame;
		}
		
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		
		public String getType() {
			return type;
		}
		
		public void setType(String type) {
			this.type = type;
		}
		
		public String getPass_word() {
			return pass_word;
		}
		
		public void setPass_word(String pass_word) {
			this.pass_word = pass_word;
		}

	
}
