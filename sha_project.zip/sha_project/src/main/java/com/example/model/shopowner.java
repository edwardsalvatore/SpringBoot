package com.example.model;


import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
@Table(name="shopower")
public class shopowner{
		@Id
		private int id;
		private String n_ame;
		private String dob;
		private String address;
		private int shop_id;
	
		@Override
		public String toString() {
			return "shopower [id=" + id + ", n_ame=" + n_ame + ", dob=" + dob + ", address=" + address + ", shop_id="
					+ shop_id + "]";
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getN_ame() {
			return n_ame;
		}
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getShop_id() {
			return shop_id;
		}
		public void setShop_id(int shop_id) {
			this.shop_id = shop_id;
		}
		

}