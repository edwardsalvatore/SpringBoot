package com.example.model;


import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
public class customer{
		@Id
		private int id;
		private String n_ame;
		private int order_id;
		private long phone;
		private String email;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getN_ame() {
			return n_ame;
		}
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		public int getOrder_id() {
			return order_id;
		}
		public void setOrder_id(int order_id) {
			this.order_id = order_id;
		}
		public long getPhone() {
			return phone;
		}
		public void setPhone(long phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		@Override
		public String toString() {
			return "customer [id=" + id + ", n_ame=" + n_ame + ", order_id=" + order_id + ", phone=" + phone
					+ ", email=" + email + "]";
		}
		
}
