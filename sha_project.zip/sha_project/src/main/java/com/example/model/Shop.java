

package com.example.model;

import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
public class Shop{

		@Id
		private int shopid;
		private String shopcatagory;
		private int shopemployeeid;
		private String shopname;
		private String customers;
		private String shopstsatus;
		private int shopowner;
		private String leasestatus;
		@Override
	public String toString() {
		return "Shop [shopid=" + shopid + ", shopcatagory=" + shopcatagory + ", shopemployeeid=" + shopemployeeid
				+ ", shopname=" + shopname + ", customers=" + customers + ", shopstsatus=" + shopstsatus
				+ ", shopowner=" + shopowner + ", leasestatus=" + leasestatus + "]";
	}
		public int getShopid() {
		return shopid;
	}
	public void setShopid(int shopid) {
		this.shopid = shopid;
	}
	public String getshopcatagory() {
		return shopcatagory;
	}
	public void setshopcatagory(String shopcatagory) {
		this.shopcatagory = shopcatagory;
	}
	public int getshopemployeeid() {
		return shopemployeeid;
	}
	public void setshopemployeeid(int shopemployeeid) {
		this.shopemployeeid = shopemployeeid;
	}
	public String getshopname() {
		return shopname;
	}
	public void setshopname(String shopname) {
		this.shopname = shopname;
	}
	public String getCustomers() {
		return customers;
	}
	public void setCustomers(String customers) {
		this.customers = customers;
	}
	public String getshopstsatus() {
		return shopstsatus;
	}
	public void setshopstsatus(String shopstsatus) {
		this.shopstsatus = shopstsatus;
	}
	public int getshopowner() {
		return shopowner;
	}
	public void setshopowner(int shopowner) {
		this.shopowner = shopowner;
	}
	public String getleasestatus() {
		return leasestatus;
	}
	public void setleasestatus(String leasestatus) {
		this.leasestatus = leasestatus;
	}
}