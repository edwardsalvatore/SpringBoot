package com.example.model;


import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
public class item{
		@Id
		private int id;
		private String n_ame;
		private String manufacturing;
		private String expiry;
		private float price;
		private String catagory;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getN_ame() {
			return n_ame;
		}
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		public String getManufacturing() {
			return manufacturing;
		}
		public void setManufacturing(String manufacturing) {
			this.manufacturing = manufacturing;
		}
		public String getexpiry() {
			return expiry;
		}
		public void setexpiry(String expiry) {
			this.expiry = expiry;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public String getCatagory() {
			return catagory;
		}
		public void setCatagory(String catagory) {
			this.catagory = catagory;
		}
		@Override
		public String toString() {
			return "item [id=" + id + ", n_ame=" + n_ame + ", manufacturing=" + manufacturing + ", expiry=" + expiry
					+ ", price=" + price + ", catagory=" + catagory + "]";
		}
		
}
