

package com.example.model;


import javax.persistence.Id;
import javax.persistence.Table;


import javax.persistence.Entity;


@Entity
@Table(name = "malladmin")
public class MallAdmin{
		@Id
		private int id;
		private String n_ame;
		private String pass_word;
		private int mall;
		private long phone;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getN_ame() {
			return n_ame;
		}
		public void setN_ame(String n_ame) {
			this.n_ame = n_ame;
		}
		public String getPass_word() {
			return pass_word;
		}
		public void setPass_word(String pass_word) {
			this.pass_word = pass_word;
		}
		public int getMall() {
			return mall;
		}
		public void setMall(int mall) {
			this.mall = mall;
		}
		public long getPhone() {
			return phone;
		}
		public void setPhone(long phone) {
			this.phone = phone;
		}
		@Override
		public String toString() {
			return "MallAdmin [id=" + id + ", n_ame=" + n_ame + ", pass_word=" + pass_word + ", mall=" + mall
					+ ", phone=" + phone + "]";
		}
		
}