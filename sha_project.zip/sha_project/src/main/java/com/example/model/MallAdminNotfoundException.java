package com.example.model;


public class MallAdminNotfoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
