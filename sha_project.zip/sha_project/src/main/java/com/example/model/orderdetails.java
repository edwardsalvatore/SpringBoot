package com.example.model;


import javax.persistence.Id;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import javax.persistence.Entity;


@Entity
public class orderdetails{
		@Id
		private int orderid;
		private String dateofpurchase;
		private float total;
		private int customer_id;
		private int shop_id;
		public int getOrderid() {
			return orderid;
		}
		public void setOrderid(int orderid) {
			this.orderid = orderid;
		}
		public String getDateofpurchase() {
			return dateofpurchase;
		}
		public void setDateofpurchase(String dateofpurchase) {
			this.dateofpurchase = dateofpurchase;
		}
		public float getTotal() {
			return total;
		}
		public void setTotal(float total) {
			this.total = total;
		}
		public int getCustomer_id() {
			return customer_id;
		}
		public void setCustomer_id(int customer_id) {
			this.customer_id = customer_id;
		}
		public int getShop_id() {
			return shop_id;
		}
		public void setShop_id(int shop_id) {
			this.shop_id = shop_id;
		}
		@Override
		public String toString() {
			return "orderdetails [orderid=" + orderid + ", dateofpurchase=" + dateofpurchase + ", total=" + total
					+ ", customer_id=" + customer_id + ", shop_id=" + shop_id + "]";
		}
		
}
